--
-- TestScript.lua
--

print('Hello!')